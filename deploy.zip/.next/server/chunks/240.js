exports.id=240,exports.ids=[240],exports.modules={5254:(e,t,s)=>{Promise.resolve().then(s.bind(s,1085)),Promise.resolve().then(s.t.bind(s,4080,23))},619:()=>{},1363:(e,t,s)=>{Promise.resolve().then(s.t.bind(s,3642,23)),Promise.resolve().then(s.t.bind(s,7586,23)),Promise.resolve().then(s.t.bind(s,7838,23)),Promise.resolve().then(s.t.bind(s,8057,23)),Promise.resolve().then(s.t.bind(s,7741,23)),Promise.resolve().then(s.t.bind(s,3118,23))},1085:(e,t,s)=>{"use strict";s.d(t,{default:()=>d});var r=s(7247),a=s(6171),o=s(2337),n=s(2134),i=s(9906),c=s(4178),l=s(1929);let u=[{name:"Home",href:"/dashboard",icon:a.Z},{name:"Invoices",href:"/dashboard/invoices",icon:o.Z},{name:"Customers",href:"/dashboard/customers",icon:n.Z}];function d(){let e=(0,c.usePathname)();return r.jsx(r.Fragment,{children:u.map(t=>{let s=t.icon;return(0,r.jsxs)(i.default,{href:t.href,className:(0,l.Z)("flex h-[48px] grow items-center justify-center gap-2 rounded-md bg-gray-50 p-3 text-sm font-medium hover:bg-sky-100 hover:text-blue-600 md:flex-none md:justify-start md:p-2 md:px-3",{"bg-sky-100 text-blue-600":e===t.href}),children:[r.jsx(s,{className:"w-6"}),r.jsx("p",{className:"hidden md:block",children:t.name})]},t.name)})})}},8075:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>o});var r=s(2051),a=s(989);function o({children:e}){return(0,r.jsxs)("div",{className:"flex h-screen flex-col md:flex-row md:overflow-hidden",children:[r.jsx("div",{className:"w-full flex-none md:w-64",children:r.jsx(a.default,{})}),r.jsx("div",{className:"flex-grow p-6 md:overflow-y-auto md:p-12",children:e})]})}},4403:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>i,metadata:()=>n});var r=s(2051);s(5832);var a=s(6793),o=s.n(a);let n={title:{template:"%s | Acme Dashboard",default:"Acme Dashboard"},description:"Acme is a fictional company used for demonstration purposes only.",metadataBase:new URL("https://next-learn-dashboard.vercel.sh")};function i({children:e}){return r.jsx("html",{lang:"en",children:r.jsx("body",{className:`${o().className} antialiased`,children:e})})}},8397:(e,t,s)=>{"use strict";s.d(t,{BX:()=>h,D1:()=>m,Kb:()=>E,NI:()=>c,V_:()=>d,qu:()=>l,t2:()=>i,x4:()=>u});var r=s(5900),a=s(9870),o=s(6778);let n=new r.Pool({connectionString:process.env.POSTGRES_URL,ssl:{rejectUnauthorized:!1}});async function i(){(0,o.unstable_noStore)();try{console.log("Fetching revenue data..."),await new Promise(e=>setTimeout(e,3e3));let e=await n.query("SELECT * FROM revenue");return console.log("Data fetch completed after 3 seconds."),e.rows}catch(e){console.error("Database Error:",e)}}async function c(){(0,o.unstable_noStore)();try{return console.log("Fetching latest invoice data..."),await new Promise(e=>setTimeout(e,3200)),(await n.query(`SELECT invoices.amount, customers.name, customers.image_url, customers.email, invoices.id
      FROM invoices
      JOIN customers ON invoices.customer_id = customers.id
      ORDER BY invoices.date DESC
      LIMIT 5`)).rows.map(e=>({...e,amount:(0,a.xG)(e.amount)}))}catch(e){console.error("Database Error:",e)}}async function l(){(0,o.unstable_noStore)();try{console.log("Fetching card data..."),await new Promise(e=>setTimeout(e,800));let e=n.query("SELECT COUNT(*) FROM invoices"),t=n.query("SELECT COUNT(*) FROM customers"),s=n.query(`
      SELECT
        SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) AS "paid",
        SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) AS "pending"
      FROM invoices
    `),r=await Promise.all([e,t,s]),o=Number(r[0].rows[0].count??"0"),i=Number(r[1].rows[0].count??"0"),c=(0,a.xG)(r[2].rows[0].paid??"0"),l=(0,a.xG)(r[2].rows[0].pending??"0");return{numberOfCustomers:i,numberOfInvoices:o,totalPaidInvoices:c,totalPendingInvoices:l}}catch(e){console.error("Database Error:",e)}}async function u(e,t){(0,o.unstable_noStore)();try{return(await n.query(`
      SELECT
        invoices.id,
        invoices.amount,
        invoices.date,
        invoices.status,
        customers.name,
        customers.email,
        customers.image_url
      FROM invoices
      JOIN customers ON invoices.customer_id = customers.id
      WHERE
        customers.name ILIKE $1 OR
        customers.email ILIKE $1 OR
        invoices.amount::text ILIKE $1 OR
        invoices.date::text ILIKE $1 OR
        invoices.status ILIKE $1
      ORDER BY invoices.date DESC
      LIMIT $2 OFFSET $3
    `,[`%${e}%`,6,(t-1)*6])).rows}catch(e){console.error("Database Error:",e)}}async function d(e){(0,o.unstable_noStore)();try{let t=await n.query(`
      SELECT COUNT(*)
      FROM invoices
      JOIN customers ON invoices.customer_id = customers.id
      WHERE
        customers.name ILIKE $1 OR
        customers.email ILIKE $1 OR
        invoices.amount::text ILIKE $1 OR
        invoices.date::text ILIKE $1 OR
        invoices.status ILIKE $1
    `,[`%${e}%`]);return Math.ceil(Number(t.rows[0].count)/6)}catch(e){console.error("Database Error:",e)}}async function m(e){(0,o.unstable_noStore)();try{let t=(await n.query(`
      SELECT
        invoices.id,
        invoices.customer_id,
        invoices.amount,
        invoices.status
      FROM invoices
      WHERE invoices.id = $1
    `,[e])).rows.map(e=>({...e,amount:e.amount/100}));return console.log(t),t[0]}catch(e){console.error("Database Error:",e)}}async function h(){try{return(await n.query(`
      SELECT
        customers.id,
        customers.name,
        customers.email,
    `)).rows}catch(e){return console.error("Database Error:",e),[]}}async function E(e){try{return(await n.query(`
      SELECT
        customers.id,
        customers.name,
        customers.email,
        customers.image_url,
        COUNT(invoices.id) AS total_invoices,
        SUM(CASE WHEN invoices.status = 'pending' THEN invoices.amount ELSE 0 END) AS total_pending,
        SUM(CASE WHEN invoices.status = 'paid' THEN invoices.amount ELSE 0 END) AS total_paid
      FROM customers
      LEFT JOIN invoices ON customers.id = invoices.customer_id
      WHERE
        customers.name ILIKE $1 OR
        customers.email ILIKE $1
      GROUP BY customers.id, customers.name, customers.email, customers.image_url
      ORDER BY customers.name ASC
    `,[`%${e}%`])).rows.map(e=>({...e,total_pending:(0,a.xG)(e.total_pending),total_paid:(0,a.xG)(e.total_paid)}))}catch(e){return console.error("Database Error:",e),[]}}n.connect().then(()=>console.log("Connected to the database")).catch(e=>console.error("Database connection error:",e))},9870:(e,t,s)=>{"use strict";s.d(t,{p9:()=>a,tk:()=>o,xG:()=>r});let r=e=>(e/100).toLocaleString("en-US",{style:"currency",currency:"USD"}),a=(e,t="en-US")=>{let s=new Date(e);return new Intl.DateTimeFormat(t,{day:"numeric",month:"short",year:"numeric"}).format(s)},o=e=>{let t=[],s=1e3*Math.ceil(Math.max(...e.map(e=>e.revenue))/1e3);for(let e=s;e>=0;e-=1e3)t.push(`$${e/1e3}K`);return{yAxisLabels:t,topLabel:s}}},5230:(e,t,s)=>{"use strict";s.d(t,{Z:()=>i});var r=s(2051),a=s(7343),o=s(6410),n=s.n(o);function i(){return(0,r.jsxs)("div",{className:`${n().className} flex flex-row items-center leading-none text-white`,children:[r.jsx(a.Z,{className:"h-12 w-12 rotate-[15deg]"}),r.jsx("p",{className:"text-[44px]",children:"Acme"})]})}},989:(e,t,s)=>{"use strict";s.r(t),s.d(t,{$$ACTION_0:()=>d,default:()=>u});var r=s(2051),a=s(4214);s(4674);var o=s(2349);let n=(0,s(5347).createProxy)(String.raw`/Users/rubenahlin/Documents/Visual Studio Code/Repository/cicd/app/ui/dashboard/nav-links.tsx#default`);var i=s(5230),c=s(613),l=s(2032);function u(){return(0,r.jsxs)("div",{className:"flex h-full flex-col px-3 py-4 md:px-2",children:[r.jsx(o.default,{className:"mb-2 flex h-20 items-end justify-start rounded-md bg-blue-600 p-4 md:h-40",href:"/",children:r.jsx("div",{className:"w-32 text-white md:w-40",children:r.jsx(i.Z,{})})}),(0,r.jsxs)("div",{className:"flex grow flex-row justify-between space-x-2 md:flex-col md:space-x-0 md:space-y-2",children:[r.jsx(n,{}),r.jsx("div",{className:"hidden h-auto w-full grow rounded-md bg-gray-50 md:block"}),r.jsx("form",{action:(0,a.j)("c460f2121b1eede4aa48396cbf01099845857a86",d),children:(0,r.jsxs)("button",{className:"flex h-[48px] w-full grow items-center justify-center gap-2 rounded-md bg-gray-50 p-3 text-sm font-medium hover:bg-sky-100 hover:text-blue-600 md:flex-none md:justify-start md:p-2 md:px-3",children:[r.jsx(c.Z,{className:"w-6"}),r.jsx("div",{className:"hidden md:block",children:"Sign Out"})]})})]})]})}async function d(){await (0,l.w7)()}},2032:(e,t,s)=>{"use strict";s.d(t,{zB:()=>d,w7:()=>m});var r=s(8984),a=s(5957),o=s(1045),n=s(7096),i=s.n(n);let c=new(s(5900)).Pool({connectionString:process.env.POSTGRES_URL,ssl:{rejectUnauthorized:!1}});async function l(e){try{return(await c.query("SELECT * FROM users WHERE email = $1",[e])).rows[0]}catch(e){throw console.error("Failed to fetch user:",e),Error("Failed to fetch user.")}}c.connect().then(()=>console.log("Connected to the database")).catch(e=>console.error("Database connection error:",e));let{auth:u,signIn:d,signOut:m}=(0,r.ZP)({pages:{signIn:"/login"},callbacks:{authorized({auth:e,request:{nextUrl:t}}){let s=!!e?.user;return t.pathname.startsWith("/dashboard")?s:!s||Response.redirect(new URL("/dashboard",t))}},providers:[],providers:[(0,a.Z)({async authorize(e){let t=o.z.object({email:o.z.string().email(),password:o.z.string().min(6)}).safeParse(e);if(t.success){let{email:e,password:s}=t.data,r=await l(e);if(!r)return null;if(await i().compare(s,r.password))return r}return console.log("Invalid credentials"),null}})]})},7481:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>a});var r=s(4564);let a=e=>[{type:"image/x-icon",sizes:"48x48",url:(0,r.fillMetadataSegment)(".",e.params,"favicon.ico")+""}]},4362:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>a});var r=s(4564);let a=e=>[{type:"image/png",width:1686,height:882,url:(0,r.fillMetadataSegment)(".",e.params,"opengraph-image.png")+"?886e7c13529660db"}]},5832:()=>{}};